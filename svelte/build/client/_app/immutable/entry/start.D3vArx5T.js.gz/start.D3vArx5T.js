import{a as t}from"../chunks/entry.CGkob4Cg.js";export{t as start};
