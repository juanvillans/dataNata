import{a as t}from"../chunks/entry.5TfcOSQl.js";export{t as start};
